class Latte extends Coffee {
    public Latte() {
        description = "Latte";
    }

    public double cost() {
        return 4.5;
    }
}