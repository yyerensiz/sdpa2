class Latte extends Coffee {
    public Latte() {
        description = "Latte";
    }

    public double cost() {
        return 600.0;
    }
}