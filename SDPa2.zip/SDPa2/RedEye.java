class RedEye extends Coffee {
    public RedEye() {
        description = "Red Eye Coffee";
    }

    public double cost() {
        return 3.0;
    }
}