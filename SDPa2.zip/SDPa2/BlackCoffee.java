class BlackCoffee extends Coffee {
    public BlackCoffee() {
        description = "Black Coffee";
    }

    public double cost() {
        return 400.0;
    }
}