class Cappuccino extends Coffee {
    public Cappuccino() {
        description = "Cappuccino";
    }

    public double cost() {
        return 4.0;
    }
}