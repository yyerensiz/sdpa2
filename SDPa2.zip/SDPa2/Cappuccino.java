class Cappuccino extends Coffee {
    public Cappuccino() {
        description = "China Cappuccino";
    }

    public double cost() {
        return 500.0;
    }
}