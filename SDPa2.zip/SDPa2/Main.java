import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Choose a coffee type: \n1. Black Coffee \n2. Cappuccino \n3. Latte \n4. Red Eye\n");
        int choice = scanner.nextInt();

        Coffee coffee = null;

        switch (choice) {
            case 1:
                coffee = new BlackCoffee();
                break;
            case 4:
                coffee = new RedEye();
                break;
            case 2:
                coffee = new Cappuccino();
                break;
            case 3:
                coffee = new Latte();
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
                System.exit(0);
        }

        while (true) {
            System.out.println("Add a decorator: \n1. Milk \n2. Sugar \n3. Syrup \n4. Done");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    coffee = new MilkDecorator(coffee);
                    break;
                case 2:
                    coffee = new SugarDecorator(coffee);
                    break;
                case 3:
                    coffee = new SyrupDecorator(coffee);
                    break;
                case 4:
                    System.out.println("Your order: " + coffee.getDescription());
                    System.out.println("Total cost: $" + coffee.cost());
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}